# 视觉规划与提示词

## 简报

将已有信息整理为：产品与已确认事实、受众、渠道、图片目的、参考素材的角色、语言、画幅、风格、配色、禁用内容与交付格式。

产品照片约束“卖的是什么”；风格参考约束“如何表现”。不要把参考海报中的品牌、功能、型号或性能数字转移到另一款产品上。

## 转化驱动

选择一个主导动机，其余作为辅助：

| 动机 | 图片重点 | 可用内容 |
| --- | --- | --- |
| 外观与质感 | 看清产品、配色、工艺和细节 | 完整外观、微距、可观察结构、使用场景 |
| 解决具体问题 | 解释问题与解决方式 | 有依据的功能、操作流程、真实对比 |
| 情绪与生活方式 | 传达使用语境与身份认同 | 桌面、居家、通勤、礼赠等场景 |

没有真实证明材料时，省略对应宣传或在设计草稿中标记待确认；不要把占位评分、认证、销量或优惠直接放进可发布成品。

## 图片清单

单张修改不扩展成整套。整套没有指定数量时，可从以下结构选择 5 张主图和 7–9 张详情图，再按真实产品与素材调整。

| 主图 | 目的 |
| --- | --- |
| H01 | 推荐首图，完整、清楚地展示产品和核心视觉主张 |
| H02 | 核心功能或质感细节 |
| H03 | 与目标人群相关的使用场景 |
| H04 | 不同角度、结构或有依据的对比 |
| H05 | 补充外观、组合或已有保障信息 |

| 详情 | 目的 |
| --- | --- |
| D01 | 首屏承接，产品与主要利益 |
| D02 | 实际需求或使用问题 |
| D03 | 功能或结构解释 |
| D04 | 关键细节与证据 |
| D05 | 使用方法或操作步骤 |
| D06 | 使用场景 |
| D07 | 材质、工艺或配置等已确认信息 |
| D08 | 参数、适用范围、FAQ 或收尾 |

不是每款产品都适合这些模块。没有性能证明时，外观、结构、配色和场景通常比虚构技术参数更合适。

每张清单记录：编号、用途、模板、视角、景别、主标题、支撑事实、画幅、输出格式、是否需要原生可编辑文字。

## Campaign Style Lock

多图任务锁定：

1. 视觉方向与受众。
2. 背景、文字、强调色的具体色值。
3. 冷暖调与光源方向、软硬程度。
4. 主标题、正文和标签的字体系统。
5. 背景材质、深浅背景的切换方式。
6. 网格、留白、分栏、边框和信息层级。
7. 图标和技术标注的线宽、形状及颜色。
8. 产品身份、真实比例与必须保留的可见结构。

示例，需替换成当前项目已经确认的风格：

```text
Campaign Style Lock: a cohesive ecommerce visual system; #F6F5F1 light neutral background, #24282B text, one user-approved accent color. Consistent sans-serif typography, thin-line callouts, restrained labels and clear spacing. Soft neutral upper-left light and realistic product texture. Preserve the referenced product's proportions, components and visible markings. Dark and light screens follow the same design system. No palette drift, mixed icon styles or warped product geometry.
```

每张提示词第一段使用同一段已确认的风格锁。修订配色时，同步更新风格锁、当前设计、导出图片与预览；素材照片的真实颜色和装饰色应分清用途。

## 构图与浏览节奏

- 在清单中明确分配完整外观、中景、局部和微距，而不是连续重复同一视角。
- 在资料允许的情况下，组合俯拍、正侧面、低角度、斜侧面和背面。新角度不能虚构接口、装配或内部结构。
- 首图优先保证产品完整可辨；特写应标明其用途，必要时配一张完整外观作参照。
- 控制标题、证据和注释的主次，移动端缩略图也应能读懂主要信息。
- 产品占比约 30–40%、留白约 45% 可作为初始构图参考；实际以产品形状、平台和用户指定版式为准。
- 深浅背景、完整产品与局部特写交替应服务于内容，不为变化而变化。

## 提示词结构

```text
Campaign Style Lock: [the same confirmed style lock]
Use case / purpose: [hero image, detail screen, scene, macro...]
Input images: [product identity, camera-angle anchor, style reference...]
Subject and verified facts: [...]
Composition and camera: [view, shot size, complete-product margins...]
Lighting and material rendering: [...]
Colors and background: [hex values...]
Text treatment: [short exact copy, or text-free artwork for native typesetting]
Aspect ratio, product occupancy and whitespace: [...]
Constraints: [what must remain accurate; concrete errors to avoid]
```

提示词以清晰、简洁为主。英文可作为默认；精确中文文案单独引用。复杂长文、规格表和需要后期修改的文字，优先用可编辑排版工具添加。

详情图应说明信息结构，例如双栏标注、三项细节、步骤流程、参数区或场景标签。单纯换角度的照片不能替代所有详情模块。

## 模板使用

从 [模板索引](template-catalog.md) 选择匹配的 JSON，读取 `prompt_template`、合适的 `variants` 与 `category_tips`，仅替换当前任务有资料支撑的字段。模板是起点，用户已经确认的设计和事实优先。
