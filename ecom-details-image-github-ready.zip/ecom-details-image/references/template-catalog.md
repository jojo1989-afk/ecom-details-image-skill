# 模板索引

保留上游的 25 个 JSON 模板。按图片用途选择最相关的 1–3 个文件，读取其 `prompt_template`、适用变体和品类建议；无需一次加载全部模板。

| 编号 | 模板文件 | 常见用途或触发词 |
| --- | --- | --- |
| 01 | [白底/纯色底产品主图](templates/01-hero-image.json) | 白底图、主图、hero image、白背景 |
| 02 | [场景化生活图](templates/02-lifestyle-scene.json) | 场景图、生活图、lifestyle、使用场景 |
| 03 | [平铺图](templates/03-flat-lay.json) | 平铺图、flat lay、俯拍、top-down |
| 04 | [细节微距图](templates/04-detail-macro.json) | 细节图、微距、macro、特写 |
| 05 | [促销海报/Banner](templates/05-poster-banner.json) | 海报、poster、banner、促销 |
| 06 | [社交媒体素材](templates/06-social-media.json) | 社交媒体、小红书、instagram、tiktok |
| 07 | [UGC风格/买家秀](templates/07-ugc-style.json) | UGC、买家秀、用户生成、真实用户 |
| 08 | [模特展示图](templates/08-model-showcase.json) | 模特、model、人物展示、模特图 |
| 09 | [使用前后对比图](templates/09-before-after.json) | 对比、before after、前后、效果对比 |
| 10 | [包装设计展示](templates/10-packaging.json) | 包装、packaging、礼盒、gift box |
| 11 | [信息图/A+Content](templates/11-infographic.json) | 信息图、infographic、A+、详情页 |
| 12 | [创意概念广告图](templates/12-creative-concept.json) | 创意图、概念图、creative、概念广告 |
| 13 | [尺寸规格+使用步骤图](templates/13-size-spec.json) | 尺寸、规格、尺寸图、使用步骤 |
| 14 | [多产品套装/组合展示](templates/14-multi-product.json) | 套装、组合、多产品、bundle |
| 15 | [电商直播间场景](templates/15-livestream.json) | 直播、livestream、直播间、电商直播 |
| 16 | [虚拟试穿/产品融入场景](templates/16-try-on-virtual.json) | 试穿、融入、虚拟试穿、try on |
| 17 | [技术拆解/爆炸图](templates/17-exploded-view.json) | 拆解图、爆炸图、exploded view、技术图 |
| 18 | [隐形模特](templates/18-ghost-mannequin.json) | 隐形模特、ghost mannequin、invisible model、3D服装 |
| 19 | [产品多角度网格](templates/19-multi-angle-grid.json) | 多角度、网格、grid、多面 |
| 20 | [杂志大片/封面](templates/20-magazine-editorial.json) | 杂志、封面、杂志大片、editorial |
| 21 | [季节主题网格](templates/21-seasonal-campaign.json) | 季节、四季、campaign、季节主题 |
| 22 | [奢华氛围渲染](templates/22-luxury-atmospherics.json) | 奢华、氛围、烟雾、高级感 |
| 23 | [设备界面模型](templates/23-device-mockup.json) | 设备模型、界面模型、mockup、UI展示 |
| 24 | [店铺门面/空间摄影](templates/24-storefront.json) | 店铺、门面、店面、storefront |
| 25 | [运动/健身广告](templates/25-sports-campaign.json) | 运动、健身、广告、sports |

图片用途可组合模板，但产品事实、用户要求和已确认风格优先。
