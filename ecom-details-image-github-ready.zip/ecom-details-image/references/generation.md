# 图片生成通道

## 选择方式

判断当前实际工具能力，不仅凭客户端名称推断。

1. 当前宿主具备内置生图工具：优先使用该工具，并遵循其参考图、编辑、保存和透明背景要求。
2. 没有内置工具，且用户选择了 apiz 通道：使用本仓库的 `scripts/generate_image.py`。
3. 所需通道不可用：说明当前状态，交付完整简报和提示词。只有实际生成并保存的图片才列入 Generated Files。

从内置工具切换到外部服务会改变运行条件，不自动安装、登录或提交外部付费任务。用户已经授权当前通道、范围与费用时，按既有授权继续，不重复确认相同事项。

## 宿主内置工具

- 传入当前图片的最终提示词及同一段 Campaign Style Lock。
- 明确每张参考图用于产品身份、相机角度还是视觉风格。
- 按工具要求先查看本地参考图，再编辑。
- 每张不同目的的图片使用对应提示词，避免一张拼图冒充多张交付图片。
- 生成后检查产品结构、文字与构图，将选定结果复制到用户指定目录。
- 已有原生可编辑设计的改色、改字或版式修改，使用宿主提供的对应编辑工具。

## apiz CLI 前置条件

需要 Python 3.9+、已安装的 apiz CLI，以及有效的 apiz 账户。Python 脚本只依赖标准库。

CLI 安装与服务说明见 [apiz 官方网站](https://apiz.ai/)。仓库保留的调用约定为：

```bash
apiz --version
apiz auth login
apiz models list
python3 scripts/generate_image.py --help
```

这些命令应从本仓库根目录执行。安装到宿主技能目录后，在其他工作目录调用脚本时，需要给出脚本的实际路径；相对输入与输出路径按工作目录解析。

## 配置

`--model` 优先于 `APIZ_IMAGE_MODEL`；两者都未设置时，原脚本使用 `apiz/gpt-image-2.5-flare`。这是代码中的默认值，不保证服务端永久提供该模型，也不保证固定像素或生成耗时。

配置项见 [.env.example](../.env.example)。没有指定 `--env-file` 时，脚本从当前工作目录向上寻找第一个 `.env`，不是从脚本目录开始寻找。已有环境变量不会被 `.env` 中的同名配置覆盖。

原脚本保留了历史 `IMG_*`、`OPENAI_*` 别名处理逻辑；新配置使用 `APIZ_*` 或 CLI 登录，避免不同服务的凭据与地址混用。不要把真实凭据写入提示词、日志、截图或 Git 提交。

## 参数

| 参数 | 用途 |
| --- | --- |
| `--prompt` | 直接传入提示词，与 `--prompt-file` 二选一 |
| `--prompt-file` | 从 UTF-8 文件读取提示词 |
| `--output-dir` | 下载目录，默认 `generated-images` |
| `--env-file` | 显式指定配置文件 |
| `--model` | 模型 ID |
| `--size` | 默认 `1:1`；像素写法换算为比例 |
| `--image` | 本地参考图，先上传再生成 |
| `--image-url` | 参考图 URL；同时传入本地图片时 URL 优先 |
| `--timeout` | 子进程等待上限，默认 420 秒 |
| `--format` | `png`、`jpeg`、`webp`，用作下载扩展名的回退值 |

带参考图：

```bash
python3 scripts/generate_image.py \
  --prompt-file examples/prompts/hero.txt \
  --image product.jpg \
  --size 1:1 \
  --output-dir generated-images/product-name/hero
```

参考图上传使用 `apiz upload`，解析 `public_url`。生成任务使用 `apiz generate ... --wait --json`，脚本要求任务状态为 `completed`，再下载 `result.images` 中的图片 URL。

## 输出与故障处理

- 文件名采用 `image-时间戳-序号.扩展名`。并发或批量执行时，每个任务使用独立输出目录，避免原脚本的秒级时间戳重名。
- `--size 1600x1600` 不是受支持的像素映射；使用 `1:1`，精确尺寸另由编辑工具导出。已有像素映射见脚本 `PIXEL_TO_RATIO`。
- `--format` 不转换图片编码；可识别的 URL 后缀优先。
- 单次只接收一个本地参考图或一个参考 URL。多图参考需使用具备对应能力的宿主工具。
- 超时或未完成状态不等于任务没有提交。先使用输出中的任务 ID，按 CLI 提示查询状态，避免直接重复提交产生重复任务。
- 本次未生成、下载失败或未验证的图片应标记为未完成，不列为成功文件。

本脚本负责提交与下载，不负责生成 PSD、拼接长图、文字分层、图像编码转换或精确像素重采样。
