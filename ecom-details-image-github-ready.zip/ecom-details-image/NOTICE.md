# 来源与整理说明

## 上游

- 原作者：liangdabiao。
- 原项目：[liangdabiao/ecom-details-image](https://github.com/liangdabiao/ecom-details-image)。
- 本整理版基于使用者此前下载的本地副本，不声称与上游最新提交完全相同。
- 保留 `references/templates/` 中的25个JSON模板，以及原始 `scripts/generate_image.py`。

原始出图脚本 SHA-256：

```text
69b207b8280bbe73262549849ae64b67f6ba10972edad9bd63586673f2e5666e
```

## 整理范围

- 重写面向使用者的README，明确安装、配置、使用示例、交付内容与能力边界。
- 精简SKILL入口，将视觉规划、生图和制作交付说明按需拆分。
- 补充产品一致性、实拍优化与可编辑源文件的交付说明。
- 增加技能UI元数据、匿名文字示例及离线发布检查脚本。
- 更新忽略规则与配置示例。

没有附带任何客户商品照片、聊天记录、真实密钥、商业字体或此次商品图成品。

## 许可状态

核对日期：2026-11-26。

[GitHub仓库元数据](https://api.github.com/repos/liangdabiao/ecom-details-image)的`license`字段为`null`，核对的[上游根目录](https://github.com/liangdabiao/ecom-details-image)未包含`LICENSE`文件。本整理版不替原作者新增MIT或其他开源许可，也不代表已获得额外授权。
