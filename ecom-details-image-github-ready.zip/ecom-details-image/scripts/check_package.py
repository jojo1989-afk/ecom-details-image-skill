#!/usr/bin/env python3
"""Offline checks for templates, internal links and Python syntax; no image calls."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit


def check(root: Path) -> list[str]:
    errors = []
    for name in ("SKILL.md", "README.md", "NOTICE.md", ".env.example", ".gitignore"):
        if not (root / name).is_file():
            errors.append(f"Missing file: {name}")

    skill = root / "SKILL.md"
    if skill.is_file():
        text = skill.read_text(encoding="utf-8")
        match = re.match(r"\A---\n(.*?)\n---(?:\n|$)", text, re.S)
        if not match:
            errors.append("SKILL.md must start with YAML frontmatter")
        else:
            front = match.group(1)
            if not re.search(r"^name:\s*ecom-details-image\s*$", front, re.M):
                errors.append("Unexpected or missing skill name")
            if not re.search(r"^description:\s*\S", front, re.M):
                errors.append("Missing skill description")

    templates = sorted((root / "references/templates").glob("*.json"))
    if not templates:
        errors.append("No JSON templates found")
    ids = set()
    for path in templates:
        rel = path.relative_to(root)
        try:
            item = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            errors.append(f"{rel}: {exc}")
            continue
        if not isinstance(item, dict):
            errors.append(f"{rel}: top-level value must be an object")
            continue
        for key in ("id", "name"):
            if not isinstance(item.get(key), str) or not item[key].strip():
                errors.append(f"{rel}: {key} must be a non-empty string")
        ident = item.get("id")
        if isinstance(ident, str):
            if ident in ids:
                errors.append(f"{rel}: duplicate template id {ident}")
            ids.add(ident)
        if not isinstance(item.get("prompt_template"), dict) or not item["prompt_template"]:
            errors.append(f"{rel}: prompt_template must be a non-empty object")

    for path in root.rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        for target in re.findall(r"\[[^\]\n]*\]\(([^)\n]+)\)", text):
            target = target.strip().strip("<>")
            parsed = urlsplit(target)
            if parsed.scheme or parsed.netloc or target.startswith("#"):
                continue
            if parsed.path and not (path.parent / unquote(parsed.path)).exists():
                errors.append(f"{path.relative_to(root)}: broken link {target}")

    for path in (root / "scripts").glob("*.py"):
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except SyntaxError as exc:
            errors.append(f"{path.relative_to(root)}: {exc}")

    forbidden = {".env", ".DS_Store", "Thumbs.db"}
    for path in root.rglob("*"):
        if path.is_file() and path.name in forbidden:
            errors.append(f"Local-only file in package: {path.relative_to(root)}")
    return errors


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    errors = check(root)
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    count = len(list((root / "references/templates").glob("*.json")))
    print(f"PASS: {count} templates; internal links and Python syntax checked. No image service called.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
