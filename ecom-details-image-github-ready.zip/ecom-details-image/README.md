# ecom-details-image

**面向国内与跨境电商的商品视觉创作 Skill：从产品资料与参考图，制作风格统一的主图、详情页和营销素材。**

内置 25 类场景模板，提供视觉简报、逐图提示词、整套图片规划和可选图片生成。通过 Campaign Style Lock 统一色板、字体、光线、背景与标注方式。

## 功能

- **商品主图**：完整外观、核心细节、使用场景及多角度展示。
- **详情页**：标题、卖点说明、结构标注、规格与场景模块。
- **实拍优化**：结合参考图整理修图方向，改善曝光、白平衡、背景与清晰度，保持产品比例。
- **营销素材**：广告、社媒、Banner、包装与创意视觉。
- **多图一致性**：固定设计语言，安排不同视角、景别与浏览节奏。
- **事实约束**：区分用户提供的信息、照片可见特征和待确认参数。

整套商品图默认规划 **5 张主图 + 7–9 张详情图**；用户指定的数量、尺寸和范围优先。也可以只生成提示词、单张图片或修改指定页面。

## 运行方式

| 方式 | 所需条件 | 可交付内容 |
| --- | --- | --- |
| Brief / Prompt | 能读取 Skill 的 AI 代理 | 视觉简报、图片清单、风格锁、提示词与文案 |
| 宿主内置生图 | 当前会话具备图片生成工具 | 上述内容与生成图片 |
| apiz CLI | Python 3.9+、apiz CLI 及可用账户 | 通过脚本提交任务并下载图片 |
| 可编辑设计文件 | 宿主另有设计编辑工具及所需字体 | 按实际工具能力制作和验证源文件 |

这是给 AI 代理使用的 Skill，不是独立桌面软件。`scripts/generate_image.py` 是可选的出图辅助脚本，仅使用 Python 标准库。

## 安装

下载本仓库并解压，或先 Fork 到自己的 GitHub 账户。将整个 `ecom-details-image` 文件夹放入宿主支持的技能目录。

| 宿主 | 个人技能目录 | 项目技能目录 | 显式调用 |
| --- | --- | --- | --- |
| Codex | `~/.agents/skills/ecom-details-image/` | `.agents/skills/ecom-details-image/` | `$ecom-details-image` |
| Claude Code | `~/.claude/skills/ecom-details-image/` | `.claude/skills/ecom-details-image/` | `/ecom-details-image` |

目录与调用方式参考 [Codex 官方说明](https://learn.chatgpt.com/docs/build-skills) 和 [Claude Code 官方说明](https://code.claude.com/docs/en/skills)。使用其他宿主或旧版客户端时，按其实际技能目录安装，避免重复安装同名技能。

从解压后的仓库根目录执行以下命令，可复制到 Codex 的个人技能目录；请先处理已有的同名安装：

```bash
mkdir -p ~/.agents/skills/ecom-details-image
cp -R SKILL.md README.md NOTICE.md .env.example .gitignore \
  agents references scripts examples \
  ~/.agents/skills/ecom-details-image/
```

## 快速开始

在支持的代理中调用 Skill，并附上产品图：

```text
用 ecom-details-image 为这款产品制作 5 张主图和 8 张详情图。

产品：便携咖啡杯
受众：日常通勤人群
参考：我提供的产品图和配色参考
风格：简洁、有少量复古感，主色由参考图确定
要求：产品保持真实比例，包含完整展示和局部特写。
文案：只使用我已确认的参数，其他信息先省略。
尺寸：主图 1:1，详情图 2:3
交付：PNG、图片清单与预览
保存位置：我指定的项目文件夹
```

只需要提示词时，补充“本次仅输出简报与提示词”。修改已确认的方案时，明确页码和保留项。

更多输入结构见 [商品简报示例](examples/product-brief.md)。

## 可选：通过 apiz CLI 出图

当前会话已有可用生图工具时，按宿主工具工作流执行，无需配置此脚本。选择 apiz 通道时，先按 [apiz 官方说明](https://apiz.ai/) 安装 CLI，再检查并登录：

```bash
apiz --version
apiz auth login
python3 scripts/generate_image.py --help
```

从仓库根目录运行示例：

```bash
python3 scripts/generate_image.py \
  --prompt-file examples/prompts/hero.txt \
  --size 1:1 \
  --output-dir generated-images/demo/hero
```

制作自己的产品图时，将参考图片放到 `product.jpg`，再增加参数：

```bash
python3 scripts/generate_image.py \
  --prompt-file examples/prompts/hero.txt \
  --image product.jpg \
  --size 1:1 \
  --output-dir generated-images/demo/hero
```

本地参考图会由 `apiz upload` 上传到 apiz 服务；脚本再提交任务并下载结果。服务费用、模型可用性和输出规格由对应服务决定。

可选配置：

```bash
cp .env.example .env
```

| 变量 | 用途 |
| --- | --- |
| `APIZ_IMAGE_MODEL` | 模型 ID；未设置时采用原脚本默认值 |
| `APIZ_API_KEY` | 可选的 apiz 凭据；已使用 CLI 登录时通常无需配置 |
| `APIZ_BASE_URL` | 可选的服务地址 |
| `APIZ_BIN` | CLI 不在 PATH 中时指定可执行文件路径 |

新配置使用 `APIZ_*` 变量，不要将不同服务商的凭据混用。真实 `.env` 与生成文件已加入忽略规则。完整参数、配置加载位置与脚本限制见 [生图通道说明](references/generation.md)。

## 交付结构

代理整理整套商品图时，建议使用：

```text
generated-images/product-name/
├── brief.md
├── image-pack-plan.json
├── prompts/
├── hero/                  # 主图
├── detail/                # 详情图
├── source/                # 仅在已制作源文件时提供
└── preview/               # 总览或浏览预览
```

这是交付约定，不是脚本自动创建的全部目录。脚本默认下载为 `image-时间戳-序号.扩展名`；主图与详情的编号、重命名和归档由代理整理。

## 可编辑 PSD

可以在需求中注明需要文字可编辑的 PSD。代理应先检查是否有可用的设计编辑工具，再将产品图、背景、标题、说明和参数分层制作，并重新打开验证文字层。

**本仓库不内置通用 PSD 生成器。** 图片生成工具返回的文字通常属于位图；仅把合成图片放入 PSD，不能视为文字可编辑。具体流程见 [制作与交付规范](references/production-and-delivery.md)。

## 目录

```text
ecom-details-image/
├── SKILL.md
├── README.md
├── NOTICE.md
├── .env.example
├── .gitignore
├── agents/openai.yaml
├── examples/
│   ├── product-brief.md
│   └── prompts/hero.txt
├── references/
│   ├── visual-workflow.md
│   ├── generation.md
│   ├── production-and-delivery.md
│   ├── template-catalog.md
│   └── templates/          # 25 个 JSON 模板
└── scripts/
    ├── generate_image.py
    └── check_package.py
```

模板涵盖主图、场景、平铺、微距、海报、社媒、UGC、模特、对比、包装、信息图等，完整列表见 [模板索引](references/template-catalog.md)。

## 限制

- 产品外观一致性与文字准确性需要检查，不能仅凭一次生成保证。
- 未提供的材质、性能、内部结构、尺寸、认证或促销信息不应补成真实卖点。
- `--size` 中的像素写法会换算为比例，不保证精确像素；`--format` 是下载扩展名的回退值，不进行格式转换。
- 原脚本单次接受一张本地参考图或一个参考图 URL；长图拼接、源文件编辑与精确尺寸导出需要宿主的其他工具。
- 只有 Brief / Prompt 能力时，应明确交付提示词，不宣称图片已经生成。

## 贡献

欢迎改进模板、示例和工作流说明。新增模板请保留统一 JSON 结构、唯一 `id` 和可执行的示例，并更新模板索引。

提交前运行离线检查：

```bash
python3 scripts/check_package.py
```

检查覆盖模板 JSON、内部文件链接与 Python 语法，不调用生图服务。请将产品资料、客户素材、聊天记录、密钥和生成结果留在项目输出目录中。

## 来源与许可

本整理版基于 [liangdabiao/ecom-details-image](https://github.com/liangdabiao/ecom-details-image)，保留其 25 个模板与原始出图脚本，整理了技能入口、说明和交付规范。

截至 2026-11-26，核对的上游仓库未提供 `LICENSE`。本整理版未自行添加 MIT 或其他开源授权；来源与修改范围见 [NOTICE.md](NOTICE.md)。
